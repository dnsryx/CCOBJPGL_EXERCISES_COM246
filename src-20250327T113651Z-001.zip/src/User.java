public class User {

    private String username;
    private String password;

    // constructor
    User(String uname, String pword){
        this.username = uname;
        this.password = pword;
    }

    // get Method
    public String getUsername(){
        return this.username;
    }
}

